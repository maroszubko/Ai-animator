export default function handler(req,res){
  // placeholder for Stripe integration (create checkout session / webhooks)
  res.status(200).json({ ok: true, message: 'Stripe placeholder - add keys and implement checkout' });
}
