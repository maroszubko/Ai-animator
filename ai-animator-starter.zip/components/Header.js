export default function Header(){ return (<header className="py-6"><div className="container mx-auto text-center">AI Animator</div></header>) }
