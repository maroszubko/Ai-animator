export default function Footer(){ return (<footer className="py-6 mt-10 text-sm text-center">© AI Animator</footer>) }
