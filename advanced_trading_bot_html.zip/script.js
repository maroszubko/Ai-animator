
// --- Symbols to track ---
const symbols = [
  { name: "BTC/USDT", api: "BTCUSDT" },
  { name: "ETH/USDT", api: "ETHUSDT" },
  { name: "BNB/USDT", api: "BNBUSDT" },
  { name: "GOLD", api: "XAUUSDT" } // Gold on Binance futures proxy
];

// --- Sound alert ---
const alertSound = new Audio("https://actions.google.com/sounds/v1/alarms/beep_short.ogg");

// --- Helper indicators ---
function computeRSI(closes, period = 14) {
  if (closes.length < period + 1) return null;
  let gains = 0, losses = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff > 0) gains += diff;
    else losses -= diff;
  }
  const rs = gains / (losses || 1);
  return 100 - (100 / (1 + rs));
}

function computeMACD(closes) {
  if (closes.length < 60) return null;
  const ema = (period, data) => {
    const k = 2 / (period + 1);
    let emaVal = data[0];
    for (let i = 1; i < data.length; i++) emaVal = data[i] * k + emaVal * (1 - k);
    return emaVal;
  };
  const ema12 = ema(12, closes);
  const ema26 = ema(26, closes);
  return ema12 - ema26;
}

function detectEngulfing(c) {
  const prev = c[c.length - 2];
  const last = c[c.length - 1];
  const prevRed = prev.close < prev.open;
  const lastGreen = last.close > last.open;
  const engulf = lastGreen && prevRed && last.close > prev.open && last.open < prev.close;
  return engulf;
}

// --- Fetch candles ---
async function fetchCandles(api) {
  const url = `https://api.binance.com/api/v3/klines?symbol=${api}&interval=1m&limit=60`;
  const res = await fetch(url);
  const raw = await res.json();
  return raw.map(c => ({
    open: parseFloat(c[1]),
    close: parseFloat(c[4])
  }));
}

// --- Render ---
async function update() {
  const container = document.getElementById("container");
  container.innerHTML = "";

  for (let s of symbols) {
    try {
      const candles = await fetchCandles(s.api);
      const closes = candles.map(c => c.close);

      const rsi = computeRSI(closes);
      const macd = computeMACD(closes);
      const engulf = detectEngulfing(candles);

      let signal = "Žiadny signál";
      let css = "";

      if (engulf) {
        signal = "BUY (Bullish Engulfing)";
        css = "buy";
        alertSound.play();
      } else if (rsi < 30) {
        signal = "BUY (RSI oversold)";
        css = "buy";
      } else if (rsi > 70) {
        signal = "SELL (RSI overbought)";
        css = "sell";
      } else if (macd > 0) {
        signal = "BUY (MACD bullish)";
        css = "buy";
      } else if (macd < 0) {
        signal = "SELL (MACD bearish)";
        css = "sell";
      }

      container.innerHTML += `
        <div class="card">
          <h3>${s.name}</h3>
          <p class="${css}">${signal}</p>
          <p>RSI: ${rsi ? rsi.toFixed(2) : "..."}</p>
          <p>MACD: ${macd ? macd.toFixed(4) : "..."}</p>
        </div>
      `;
    } catch (e) {
      container.innerHTML += `<div class='card'><h3>${s.name}</h3><p>Error loading...</p></div>`;
    }
  }
}

setInterval(update, 5000);
update();
